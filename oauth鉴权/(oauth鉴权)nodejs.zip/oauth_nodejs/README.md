1.配置config文件内容
2.使用npm安装相应环境
3.运行main.js测试